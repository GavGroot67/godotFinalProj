extends CharacterBody3D

# --- Movement Parameters ---
@export_group("Movement")
@export var walk_speed: float = 3.0
@export var sprint_speed: float = 6.0
@export var mouse_sensitivity: float = 0.002

# --- Blink Parameters ---
@export_group("Blink Mechanic")
@export var blink_duration: float = 0.1         # Total time eyes stay closed/fading
@export var eye_strain_rate: float = 6.0       # How fast meter fills per second
@export var manual_blink_recovery: float = 0.0  # Reset value on blink

# --- Limping Head Bob Parameters ---
@export_group("Limping Bob")
@export var bob_frequency: float = 2.2          # Speed of the step cycle
@export var bob_amplitude: float = 0.12         # Deep vertical drop on the bad leg
@export var bob_h_amplitude: float = 0.06       # Side-to-side weight shift
@export var roll_tilt_amount: float = 0.05      # Camera roll intensity (radians)
@export var limp_severity: float = 1.8          # Higher values make the uneven dip harsher

# --- Node References ---
@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var blink_overlay: ColorRect = $CanvasLayer/BlinkOverlay
@onready var blink_meter: ProgressBar = $CanvasLayer/BlinkMeter

# Internal Tracking
var bob_timer: float = 0.0
var default_head_pos: Vector3 = Vector3.ZERO
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

# Mouse Rotation Tracking
var pitch: float = 0.0 # Vertical rotation tracker (X-axis)

# Blink & Strain Tracking
var eye_strain: float = 0.0
var is_blinking: bool = false

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	default_head_pos = head.position
	
	if blink_overlay:
		blink_overlay.modulate.a = 0.0
	if blink_meter:
		blink_meter.value = 0.0

func _unhandled_input(event: InputEvent) -> void:
	# MOUSE LOOK LOGIC (RE-ADDED)
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		# Rotate character body horizontally (Y-axis)
		rotate_y(-event.relative.x * mouse_sensitivity)
		
		# Rotate head pitch vertically (X-axis) and clamp to prevent flipping upside down
		pitch -= event.relative.y * mouse_sensitivity
		pitch = clamp(pitch, deg_to_rad(-89.0), deg_to_rad(89.0))
		head.rotation.x = pitch
	
	# Click window to re-capture mouse if released
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	
	# Release mouse capture with Escape
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Process eye strain meter over time
	_process_eye_strain(delta)

	# Manual Blink Input
	if Input.is_action_just_pressed("blink") and not is_blinking:
		_trigger_blink()

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	
	var current_speed := sprint_speed if Input.is_action_pressed("sprint") else walk_speed

	if direction:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, current_speed)
		velocity.z = move_toward(velocity.z, 0, current_speed)

	move_and_slide()

	_handle_limp_bob(delta)

func _process_eye_strain(delta: float) -> void:
	if is_blinking:
		return

	eye_strain += eye_strain_rate * delta
	eye_strain = clamp(eye_strain, 0.0, 100.0)

	if blink_meter:
		blink_meter.value = eye_strain

	if eye_strain >= 100.0:
		_trigger_blink()

func _trigger_blink() -> void:
	is_blinking = true
	eye_strain = manual_blink_recovery
	
	if blink_meter:
		blink_meter.value = eye_strain

	var tween := create_tween()
	
	# Fade to Black (Eyes closing)
	tween.tween_property(blink_overlay, "modulate:a", 1.0, blink_duration * 0.4)\
		.set_trans(Tween.TRANS_QUAD)\
		.set_ease(Tween.EASE_IN)
		
	# Hold Closed
	tween.tween_interval(0.08)
	
	# Fade back to Clear (Eyes opening)
	tween.tween_property(blink_overlay, "modulate:a", 0.0, blink_duration * 0.52)\
		.set_trans(Tween.TRANS_QUAD)\
		.set_ease(Tween.EASE_OUT)
		
	await tween.finished
	is_blinking = false

func _handle_limp_bob(delta: float) -> void:
	var horizontal_velocity := Vector3(velocity.x, 0, velocity.z)
	var speed := horizontal_velocity.length()

	if is_on_floor() and speed > 0.1:
		bob_timer += delta * speed * bob_frequency
		
		var raw_sine := sin(bob_timer)
		var vertical_dip: float = -abs(raw_sine) * limp_severity if raw_sine < 0 else sin(bob_timer)
		var horizontal_sway := cos(bob_timer * 0.5)
		
		var target_pos := Vector3(
			default_head_pos.x + (horizontal_sway * bob_h_amplitude),
			default_head_pos.y + (vertical_dip * bob_amplitude),
			default_head_pos.z
		)
		head.position = head.position.lerp(target_pos, delta * 14.0)
		
		# Keep head rotation X driven by mouse look pitch, only modulate roll (Z) on Camera3D
		var target_roll := horizontal_sway * roll_tilt_amount
		camera.rotation.z = lerp(camera.rotation.z, target_roll, delta * 10.0)
		
	else:
		bob_timer = 0.0
		head.position = head.position.lerp(default_head_pos, delta * 8.0)
		camera.rotation.z = lerp(camera.rotation.z, 0.0, delta * 8.0)
