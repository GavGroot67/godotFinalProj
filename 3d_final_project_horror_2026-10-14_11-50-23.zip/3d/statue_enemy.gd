extends CharacterBody3D

# --- Enemy Properties ---
@export var move_speed: float = 12.0          # Fast movement speed when unobserved
@export var kill_distance: float = 1.8         # Distance at which statue strikes player
@export var raycast_sight_check: bool = true   # Uses raycast to verify clear line-of-sight

# --- References ---
@export var player: CharacterBody3D            # Drag your Player node here in Inspector
@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D
@onready var visible_notifier: VisibleOnScreenNotifier3D = $VisibleOnScreenNotifier3D

# Tracking
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta

	if not player:
		move_and_slide()
		return

	# Determine if player can see this enemy
	var is_observed := _check_if_observed()

	if not is_observed:
		# MOVE TOWARD PLAYER WHILE UNWATCHED / BLINKING
		nav_agent.target_position = player.global_position
		
		if not nav_agent.is_navigation_finished():
			var next_pos: Vector3 = nav_agent.get_next_path_position()
			var direction: Vector3 = (next_pos - global_position).normalized()
			
			velocity.x = direction.x * move_speed
			velocity.z = direction.z * move_speed
			
			# Face the player instantly when moving
			look_at(Vector3(player.global_position.x, global_position.y, player.global_position.z))
		else:
			velocity.x = 0.0
			velocity.z = 0.0
			
		# Check for attack / kill radius
		var dist_to_player := global_position.distance_to(player.global_position)
		if dist_to_player <= kill_distance:
			_attack_player()
	else:
		# FREEZE INSTANTLY WHEN OBSERVED
		velocity.x = 0.0
		velocity.z = 0.0

	move_and_slide()

func _check_if_observed() -> bool:
	# 1. Player is blinking -> NOT observed
	if "is_blinking" in player and player.is_blinking:
		return false

	# 2. Not inside the camera frustum/screen -> NOT observed
	if not visible_notifier.is_on_screen():
		return false

	# 3. Direct Line-of-Sight Check (Raycast to check if a wall blocks vision)
	if raycast_sight_check:
		var space_state := get_world_3d().direct_space_state
		# Raycast from player camera position to enemy center
		var eye_pos: Vector3 = player.head.global_position if "head" in player else player.global_position
		var query := PhysicsRayQueryParameters3D.create(eye_pos, global_position)
		query.exclude = [player.get_rid(), get_rid()] # Ignore player and self
		
		var result := space_state.intersect_ray(query)
		if result: # Hit an obstacle/wall blocking direct vision
			return false

	# Player is looking right at the enemy with eyes open and no wall in between
	return true

func _attack_player() -> void:
	# Replace with your actual game over/jumpscare sequence
	print("SCP-173 snapped your neck! GAME OVER")
