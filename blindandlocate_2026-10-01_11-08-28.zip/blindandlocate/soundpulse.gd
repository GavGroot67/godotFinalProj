extends Area2D
class_name SoundPulse

@onready var collision_shape: CollisionShape2D = $CollisionShape2D

var max_radius: float = 300.0
var expand_duration: float = 0.5
var is_echo: bool = false # Prevents infinite bounce loops

# Wall detection settings
var ray_count: int = 16 # Number of sonar rays to cast
var wall_collision_mask: int = 1 # Set to 1 for default TileMap collisions (or 2 if using Layer 2)

func _ready() -> void:
	# Set sound detection collision mask (Layer 3: Enemies)
	collision_layer = 0
	set_collision_mask_value(3, true)
	
	# Connect signal to detect enemies
	area_entered.connect(_on_area_entered)
	
	# Only primary pulses cast wall reflection rays (echoes don't bounce again)
	if not is_echo:
		cast_reflection_rays()
	
	# Animate the pulse expansion using scale Tween
	expand_pulse()

func expand_pulse() -> void:
	scale = Vector2.ZERO
	var tween := create_tween()
	
	# Expand area shape linearly over expand_duration
	tween.tween_property(self, "scale", Vector2.ONE * (max_radius / 10.0), expand_duration)
	# Fade out visual/alpha
	tween.parallel().tween_property(self, "modulate:a", 0.0, expand_duration)
	
	# Destroy node once fully expanded
	tween.tween_callback(queue_free)

func cast_reflection_rays() -> void:
	var space_state := get_world_2d().direct_space_state
	var step_angle := TAU / ray_count

	for i in range(ray_count):
		var angle := step_angle * i
		var ray_direction := Vector2.RIGHT.rotated(angle)
		var ray_end := global_position + (ray_direction * max_radius)

		# Raycast parameters to check for wall collisions
		var query := PhysicsRayQueryParameters2D.create(global_position, ray_end)
		query.collision_mask = wall_collision_mask

		var result := space_state.intersect_ray(query)

		# If ray hits a wall, spawn a secondary echo pulse
		if result:
			var hit_point: Vector2 = result.position
			var hit_normal: Vector2 = result.normal
			
			# Calculate remaining energy/distance after hitting the wall
			var distance_traveled: float = global_position.distance_to(hit_point)
			var remaining_radius: float = (max_radius - distance_traveled) * 0.6 # Decay factor

			if remaining_radius > 30.0: # Only spawn echo if enough energy remains
				spawn_reflected_echo(hit_point, ray_direction.bounce(hit_normal), remaining_radius)

func spawn_reflected_echo(origin: Vector2, bounce_dir: Vector2, echo_radius: float) -> void:
	# Create a secondary pulse at the wall collision point
	var echo := duplicate() as SoundPulse
	echo.is_echo = true
	echo.global_position = origin + (bounce_dir * 5.0) # Offset slightly outside the wall
	echo.max_radius = echo_radius
	echo.expand_duration = expand_duration * (echo_radius / max_radius)
	
	get_parent().call_deferred("add_child", echo)

func _on_area_entered(area: Area2D) -> void:
	# Check if the entered area belongs to an enemy sound listener
	if area.has_method("on_sound_heard"):
		area.on_sound_heard(global_position)
