extends CharacterBody2D

@export var walk_speed: float = 180.0
@export var crouch_speed: float = 80.0
@export var step_distance_threshold: float = 50.0
@export var pulse_scene: PackedScene

# Node References
@onready var pulse_point: Marker2D = $SoundPulsePoint
@onready var visuals: Node2D = $Visuals

var distance_walked: float = 0.0
var last_position: Vector2

func _ready() -> void:
	last_position = global_position

func _physics_process(_delta: float) -> void:
	var input_vector := Vector2(
		Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
		Input.get_action_strength("move_down") - Input.get_action_strength("move_up")
	).normalized()

	var is_crouching := Input.is_action_pressed("crouch")
	var current_speed := crouch_speed if is_crouching else walk_speed

	velocity = input_vector * current_speed
	move_and_slide()

	# Rotate visuals towards movement direction
	if input_vector != Vector2.ZERO:
		visuals.rotation = input_vector.angle()

	# Pulse generation based on distance walked
	if velocity.length() > 0:
		distance_walked += global_position.distance_to(last_position)
		if distance_walked >= step_distance_threshold:
			emit_pulse(is_crouching)
			distance_walked = 0.0

	last_position = global_position

func emit_pulse(is_crouching: bool) -> void:
	if pulse_scene == null:
		return

	var pulse := pulse_scene.instantiate() as SoundPulse
	# Spawn pulse at Marker2D position
	pulse.global_position = pulse_point.global_position
	pulse.max_radius = 120.0 if is_crouching else 320.0

	get_parent().add_child(pulse)
